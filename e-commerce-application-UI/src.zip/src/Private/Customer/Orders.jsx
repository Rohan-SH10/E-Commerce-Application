import React from 'react'

const Orders = () => {
  return (
    <div>
      Orders Of Customer
    </div>
  )
}

export default Orders
