import React from 'react'

const AddAddress = () => {
  return (
    <div>
        Address
    </div>
  )
}

export default AddAddress
