import React from 'react'

const SellerDashboard = () => {
  return (
    <div>
        SellerDashboard
    </div>
  )
}

export default SellerDashboard
