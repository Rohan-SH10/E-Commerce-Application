import React from 'react'

const Explore = () => {
  return (
    <div>
        User Explore Dashboard
    </div>
  )
}

export default Explore
